#!/bin/csh
/home/asfs/GET_SPAM_MSG/trap_src/collecttrap
