export NLS_LANG=American_america.KO16KSC5601
export LC_ALL=ko_KR.eucKR
export LD_LIBRARY_PATH=/home/oracle/app/oracle/product/11.2.0/client_1/lib:
export ORACLE_BASE=/home/oracle/app/oracle/product
export ASFSDB=oraasfs/oraasfs2301@ASFS
export PATH=/home/oracle/app/oracle/product/11.2.0/client_1/bin:/usr/kerberos/bin:/usr/local/bin:/bin:/usr/bin:/home/asfsgw/bin
export LANG=ko_KR.eucKR
export CLASSPATH=.:/home/oracle/app/oracle/product/11.2.0/client_1/jlib:/home/oracle/app/oracle/product/11.2.0/client_1/rdbms/jlib:/home/oracle/app/oracle/product/11.2.0/client_1/network/jlib
export ORACLE_HOME=/home/oracle/app/oracle/product/11.2.0/client_1
export ORACLE_INCLUDE=/home/oracle/app/oracle/product/11.2.0/client_1/precomp/public



#alias
#csh
#alias cdbin  'cd ~/apps/bin'

#bash
alias cdbin='cd ~/apps/bin '
alias cdscript='cd ~/apps/script '
alias cdsrc='cd ~/sfmts/src '
