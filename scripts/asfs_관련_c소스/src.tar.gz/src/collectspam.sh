#!/bin/csh
/home/asfs/GET_SPAM_MSG/src/collectspam
