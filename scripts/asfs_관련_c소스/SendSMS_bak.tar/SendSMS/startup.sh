#!/bin/sh
while [ 1 ]
do
pid=`ps -ef | grep "sendsms" | grep -v 'grep' | awk '{print $2}'`
if [ -z $pid ] 
then
./sendsms
fi
sleep 10
done

#end of shell script
