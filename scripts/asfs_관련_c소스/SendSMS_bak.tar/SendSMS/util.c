#include "main.h"
#include <stdarg.h>

void VsmsMakeNetwork_GipAddr(GIPADDR data){
    data->callno    = htonl(data->callno);
    data->addrrsv   = htonl(data->addrrsv);
}

void VsmsMakeNetwork_GipMsgCode(GIPMSGCODE data){
    data->msgcode       = htons(data->msgcode);
    data->msgsubcode    = htons(data->msgsubcode);
}

void VsmsMakeNetwork_GipHead(GIPSHEAD data){
    data->msgverid      = htonl(data->msgverid);
    VsmsMakeNetwork_GipAddr(&data->srcaddr);
    VsmsMakeNetwork_GipAddr(&data->dstaddr);
    VsmsMakeNetwork_GipMsgCode(&data->msgcode);
    data->telsvcid      = htons(data->telsvcid);
    data->msgcodersv    = htons(data->msgcodersv);
    data->bodylen       = htonl(data->bodylen);
    data->msgseqno      = htonl(data->msgseqno);
    data->reserved2[0]  = htonl(data->reserved2[0]);
    data->reserved2[1]  = htonl(data->reserved2[1]);
}

void VsmsMakeHost_GipAddr(GIPADDR data){
    data->callno    = ntohl(data->callno);
    data->addrrsv   = ntohl(data->addrrsv);
}

void VsmsMakeHost_GipMsgCode(GIPMSGCODE data){
    data->msgcode   = ntohs(data->msgcode);
    data->msgsubcode    = ntohs(data->msgsubcode);
}

void VsmsMakeHost_GipHead(GIPSHEAD data){
    data->msgverid      = ntohl(data->msgverid);
    VsmsMakeHost_GipAddr(&data->srcaddr);
    VsmsMakeHost_GipAddr(&data->dstaddr);
    VsmsMakeHost_GipMsgCode(&data->msgcode);
    data->telsvcid      = ntohs(data->telsvcid);
    data->msgcodersv    = ntohs(data->msgcodersv);
    data->bodylen       = ntohl(data->bodylen);
    data->msgseqno      = ntohl(data->msgseqno);
    data->reserved2[0]  = ntohl(data->reserved2[0]);
	data->reserved2[1]  = ntohl(data->reserved2[1]);
}

char *GetCurDateA(char *buff)
{
    struct tm *tm;
    struct timeval tv, otv={0, 0};
    static char day[20] = "19700101000000000";

    gettimeofday(&tv, NULL);
    tv.tv_usec = tv.tv_usec / 1000;
    if(otv.tv_sec == tv.tv_sec && otv.tv_sec == tv.tv_usec) 
	{ 
		strcpy(buff, day); 
		return buff;
	}

	memcpy(&otv, &tv, sizeof(otv));
    tm = localtime(&tv.tv_sec);
    sprintf(buff, "%04d%02d%02d%02d%02d%02d%03d",
        tm->tm_year+1900, tm->tm_mon+1, tm->tm_mday,
        tm->tm_hour, tm->tm_min, tm->tm_sec, (int)tv.tv_usec);
    strcpy(day, buff);

	return buff;
}

char *GetCurTime(char *buff)
{
	struct tm *tm;
	struct timeval tv, otv={0,0};
	static char day[20] = "00:00:00.000";

	gettimeofday(&tv, NULL);
	tv.tv_usec = tv.tv_usec / 1000;
	if(otv.tv_sec == tv.tv_sec && otv.tv_sec == tv.tv_usec) 
	{
		strcpy(buff, day);
		return buff;
	}
	memcpy(&otv, &tv, sizeof(otv));
	tm = localtime(&tv.tv_sec);
	sprintf(buff, "%02d:%02d:%02d.%03d", tm->tm_hour, tm->tm_min, tm->tm_sec, (int)tv.tv_usec);
	strcpy(day, buff);
	return buff;
}   

static int chrcmp(char ch, const char *del)
{
    if ( del == NULL ) return 0;

    while( *del != 0x00 )
    {
        if( ch == *del )
        {
            return 1;
        }
        else del++;
    }
    return 0;
}

int whole_trim(char *p, const char *delim)
{
    char *str;
    str = p;

    do
    {
        if( chrcmp( *p, delim) )
        {
            p++;
            continue;
        }

        *str = *p;
        str++;
        p++;

    }while( *p != 0x00 );

    *str = 0x00;
    return 0;
}

int HSwrite(int fd, char *buff, int len)
{
	char    *cp;
	int     ret,sz, w;
	time_t  st;

	for(sz = 0, cp = buff, w = len, st=time(NULL)+5; sz < len; ) {
		if(st < time(NULL)) break;
		errno = 0;
		ret = (int)write(fd, cp, (size_t)w);
		if(ret < 0) {
			if(errno == EINTR) continue;
			sz = -1;
			break;
		}
		sz += ret;
		cp = buff + sz;
		w  = len - sz;
	}
	return sz;
}

int IFLogDumpK(char *data, int len )
{
	int i,cnt,k,pos,mlen;
	unsigned char msg[128], buf[1024], tmp[32];

	char logdate[20];
	FILE *fd;
	char log_path[100];
	char log_msg[2048];

	memset(logdate, 0x00, sizeof(logdate));
	GetCurDateA(logdate);

	memset(log_path, 0x00, sizeof(log_path));
	snprintf(log_path, 100, "./log/%.8s.log", logdate);

	if((fd=fopen(log_path, "a+")) == NULL)
	{
		printf("log file path error!!!!\n");
		exit(-1);
	}


	if(len > 0) {
		memset(log_msg, 0x00, sizeof(log_msg));	
		sprintf(log_msg, "[SEQ. 01 02 03 04 05  06 07 08 09 10  11 12 13 14 15  16 17 18 19 20]\n");
		fwrite(log_msg, strlen(log_msg), 1, fd);

		cnt = (len / 20) + ((len%20)?1:0);
		for(k = 0, pos=0; k < cnt; k++) {
			if((pos+20) > len) mlen = len - pos;
			else mlen = 20;
			memset(msg, 0x00, sizeof(msg));
			memcpy(msg, data+pos, (size_t)mlen);
			memset(buf, 0x00, sizeof(buf));
			sprintf((char *)buf, "%04d ", k*20);
			for(i = 0; i < mlen; i++) {
				sprintf((char *)tmp, "%02X", msg[i]);
				strcat((char *)buf, (char *)tmp);
				if(((i+1) % 5) == 0) { if((i+1) < mlen) strcat((char *)buf, "  "); }
				else strcat((char *)buf, " ");

			}
			memset(log_msg, 0x00, sizeof(log_msg));
			sprintf(log_msg, "[%s]\n",buf);
			fwrite(log_msg, strlen(log_msg), 1, fd);
			pos += mlen;
		}
		memset(log_msg, 0x00, sizeof(log_msg));
		sprintf(log_msg,"========================================================================\n");
		fwrite(log_msg, strlen(log_msg), 1, fd);
		fclose(fd);
	}

	return ROK;
}


int WriteLogMsg(const char *format, ...)
{
	va_list   arg;
	int       count;
	char buff[2048];
	char n_format[1024] = "%s :%4d ";
	char curdate[20];
	char logdate[20];
	FILE *fd;
	char log_path[100];
	char logmsg[2048];

	va_start( arg, format);
	strcat(n_format, format);
	count = vsprintf(buff, n_format, arg);
	va_end( arg);  

	memset(logdate, 0x00, sizeof(logdate));
	GetCurDateA(logdate);

	memset(log_path, 0x00, sizeof(log_path));
	snprintf(log_path, 100, "./log/%.8s.log", logdate);

	if((fd=fopen(log_path, "a+")) == NULL)
	{
		printf("log file path error!!!!\n");
		exit(-1);
	}

	memset(curdate, 0x00, sizeof(curdate));
	GetCurTime(curdate);

	memset(logmsg, 0x00, sizeof(logmsg));	
	snprintf(logmsg, 2048, "%s %s\n", curdate, buff);
	fwrite(logmsg, strlen(logmsg), 1, fd);
	fclose(fd);

//	printf("%s %s\n", curdate, buff);
	return ROK;
}

char* token(char* str, char* src, const char* sep) {
	int i = 0;
	if (*src == '\0') return(NULL);
	while (1) {
		if (sep[i] == '\0') {
			str -= strlen(sep);
			break;
		} else if (*src == sep[i]) {
			i++;
		} else i = 0;
		if (*src == '\0') break;
		*str++ = *src++;
	}
	*str = '\0';
	return(src);
}

int readline(FILE *fp, char *buff, int len)
{
	char *line_p;

	memset(buff, 0x00, sizeof(buff));
	if(fgets(buff, len, fp) == NULL)
		return -1;

	if((line_p = strchr(buff, '\n')) != NULL) *line_p = '\0';
	if((line_p = strchr(buff, '\r')) != NULL) *line_p = '\0';

	return 0;

	/* 사용법
	   FILE *fp = fopen("temp.txt", "r");
	   char buff[BUFFSIZE];

	   while(readline(fp, buff, BUFFSIZE) != -1)
	   {
	   logmsg(buff);
	   }

	   fclose(fp);
	 */
}
