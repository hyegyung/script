#include "main.h"
#include <unistd.h>

#define _AUTOINCREMENT
// sendsms.cfg 
int gStatus;
char gIp[16];
int gPort;

float gTps;
int gCall_interval;
int gTime_interval;
int gIntervalCount;

int gSend_skt;
int gSend_kt;
int gSend_lgt;

char gSource_cid[16];
char gSource_num[24];
char gCallback_num[24];
#ifdef _AUTOINCREMENT
int gCbnum_autoupflag;
int gCbnum_inc;
#endif
char gTelesvcid[10];

char gDest_num_skt[24];
char gDest_num_kt[24];
char gDest_num_lgt[24];
int	 gCfgLogMode;
// sendsms.cfg end

int		gSendCount;
//int		gId;
//int		gCh;
int		gFD;
int		gRetryCnt;
time_t	gLastJobTime;
time_t	gLinkTime;
time_t  gTempTime;
int		gConnect=0;

//char	ghostname[128];
char	errmsg[256];
//char	errbuf[1024];

static char _worktmp[8192];
static int  _workon = 0, _workpos = 0, _workend = 0, _worksnd = 0;

static struct linger 			s_linger_option;
static int				s_val=1;

unsigned int seqno;

int load_config()
{
    FILE *pfd;
    char buf[1024];
    char *pbuf;
    char *ptr;

    memset(buf, 0x00, sizeof(buf));


    pfd = fopen("sendsms.cfg", "r");
    if(pfd == 0 || pfd == NULL) return RFAIL;

    while((pbuf = fgets(buf, sizeof(buf), pfd)) != NULL)
    {
        if(feof(pfd))
        {
            break;
        }
        if(!strncmp(pbuf, "#", 1))
        {
            memset( buf, 0x00, sizeof(buf));
            continue;
        }
		else if(!strncmp(pbuf, "run", 3))
        {
            if((ptr = strchr(pbuf, '=')) != NULL)
            {
                gStatus = atoi(ptr+1);
            }
        }
        else if(!strncmp(pbuf, "ip", 2))
		{
			if((ptr = strchr(pbuf, '=')) != NULL)
			{
				ptr = ptr+1;
				whole_trim(ptr, "\t\n ");
				memset(gIp, 0x00, sizeof(gIp));
				strncpy(gIp, ptr, strlen(ptr));
			}
		}
		else if(!strncmp(pbuf, "port", 4))
		{
			if((ptr = strchr(pbuf, '=')) != NULL)
			{
				gPort = atoi(ptr+1);
			}

		}
		else if(!strncmp(pbuf, "tps", 3))
		{
			if((ptr = strchr(pbuf, '=')) != NULL)
			{
				gTps = 1/(float)atoi(ptr+1)*1000;
			}

		}
		else if(!strncmp(pbuf, "call_interval", 13))
		{
			if((ptr = strchr(pbuf, '=')) != NULL)
			{
				gCall_interval = atoi(ptr+1);
			}

		}
		else if(!strncmp(pbuf, "time_interval", 13))
		{
			if((ptr = strchr(pbuf, '=')) != NULL)
			{
				gTime_interval = atoi(ptr+1);
			}

		}
		else if(!strncmp(pbuf, "send_skt", 8))
		{
			if((ptr = strchr(pbuf, '=')) != NULL)
			{
				gSend_skt = atoi(ptr+1);
			}

		}
		else if(!strncmp(pbuf, "send_kt", 7))
		{
			if((ptr = strchr(pbuf, '=')) != NULL)
			{
				gSend_kt = atoi(ptr+1);
			}

		}
		else if(!strncmp(pbuf, "send_lgt", 8))
		{
			if((ptr = strchr(pbuf, '=')) != NULL)
			{
				gSend_lgt = atoi(ptr+1);
			}

		}
		else if(!strncmp(pbuf, "source_cid", 10))
		{
			if((ptr = strchr(pbuf, '=')) != NULL)
			{
				ptr = ptr+1;
				whole_trim(ptr, "\t\n ");
				memset(gSource_cid, 0x00, sizeof(gSource_cid));
				strncpy(gSource_cid, ptr, strlen(ptr));
			}

		}
		else if(!strncmp(pbuf, "source_num", 10))
		{
			if((ptr = strchr(pbuf, '=')) != NULL)
			{
				ptr = ptr+1;
				whole_trim(ptr, "\t\n ");
				memset(gSource_num, 0x00, sizeof(gSource_num));
				strncpy(gSource_num, ptr, strlen(ptr));
			}

		}
		else if(!strncmp(pbuf, "callback_num", 12))
		{
			if((ptr = strchr(pbuf, '=')) != NULL)
			{
				ptr = ptr+1;
				whole_trim(ptr, "\t\n ");
				memset(gCallback_num, 0x00, sizeof(gCallback_num));
				strncpy(gCallback_num, ptr, strlen(ptr));
			}

		}

#ifdef _AUTOINCREMENT
		else if(!strncmp(pbuf, "cbnum_autoincrement", 19))
		{
			if((ptr = strchr(pbuf, '=')) != NULL)
			{
				gCbnum_autoupflag = atoi(ptr+1);
			}

		}	
#endif
		else if(!strncmp(pbuf, "telesvcid", 9))
		{
			if((ptr = strchr(pbuf, '=')) != NULL)
			{
				ptr = ptr+1;
				whole_trim(ptr, "\t\n ");
				memset(gTelesvcid, 0x00, sizeof(gTelesvcid));
				strncpy(gTelesvcid, ptr, strlen(ptr));
			}

		}

		else if(!strncmp(pbuf, "dest_num_skt", 12))
		{
			if((ptr = strchr(pbuf, '=')) != NULL)
			{
				ptr = ptr+1;
				whole_trim(ptr, "\t\n ");
				memset(gDest_num_skt, 0x00, sizeof(gDest_num_skt));
				strncpy(gDest_num_skt, ptr, strlen(ptr));
			}

		}
		else if(!strncmp(pbuf, "dest_num_kt", 11))
		{
			if((ptr = strchr(pbuf, '=')) != NULL)
			{
				ptr = ptr+1;
				whole_trim(ptr, "\t\n ");
				memset(gDest_num_kt, 0x00, sizeof(gDest_num_kt));
				strncpy(gDest_num_kt, ptr, strlen(ptr));
			}

		}
		else if(!strncmp(pbuf, "dest_num_lgt", 12))
		{
			if((ptr = strchr(pbuf, '=')) != NULL)
			{
				ptr = ptr+1;
				whole_trim(ptr, "\t\n ");
				memset(gDest_num_lgt, 0x00, sizeof(gDest_num_lgt));
				strncpy(gDest_num_lgt, ptr, strlen(ptr));
			}

		}
		else if(!strncmp(pbuf, "dumpCode", 8))
		{
			if((ptr = strchr(pbuf, '=')) != NULL)
			{
				gCfgLogMode = atoi(ptr+1);
			}

		}
	

        memset(buf, 0, sizeof(buf));
    }       
	fclose(pfd);

    return ROK;
}

int set_config()
{
    FILE *rfd, *wfd;
    char buf[1024];
    char *pbuf;
    char *ptr;

    memset(buf, 0x00, sizeof(buf));

    rfd = fopen("sendsms.cfg", "r");
    if(rfd == 0 || rfd == NULL) return RFAIL;

    wfd = fopen(".sendsms.tmp", "w");
    if(wfd == 0 || wfd == NULL) return RFAIL;

    while((pbuf = fgets(buf, sizeof(buf), rfd)) != NULL)
    {
        if(feof(rfd))
        {
            break;
        }
        if(!strncmp(pbuf, "run=1", 5))
        {
			fwrite("run=0\n", 1, 6, wfd);
            continue;
        }
		else
		{
			fwrite(pbuf, 1, strlen(pbuf), wfd);
		}
        memset(buf, 0, sizeof(buf));
	}

	fclose(wfd);
	fclose(rfd);

	rename(".sendsms.tmp", "sendsms.cfg");
	gStatus=0;

	return ROK;
}

void print_config()
{
	logmsg("############## sendsms.conf ##############");
	logmsg("gStatus[%d]",gStatus);
	logmsg("gIp[%s]",gIp);
	logmsg("gPort[%d]",gPort);
	logmsg("gTps[%.0f]",1/gTps*1000);
	logmsg("gCall_interval[%d]", gCall_interval);
	logmsg("gTime_interval[%d]", gTime_interval);
	logmsg("gSend_skt[%d]",gSend_skt);
	logmsg("gSend_kt[%d]",gSend_kt);
	logmsg("gSend_lgt[%d]",gSend_lgt);
	logmsg("gSource_cid[%s]", gSource_cid);
	//logmsg("gSource_num[%s]", gSource_num);
	logmsg("gCallback_num[%s]", gCallback_num);
	logmsg("gCbnum_autoup[%d]", gCbnum_autoupflag);
	logmsg("gDest_num_skt[%s]", gDest_num_skt);
	logmsg("gDest_num_kt[%s]", gDest_num_kt);
	logmsg("gDest_num_lgt[%s]", gDest_num_lgt);
	logmsg("dumpCode[%d]", gCfgLogMode);
	logmsg("##########################################");
}

void MsgSeqNoIncrement()
{
	if(seqno > 999999999) 
		seqno = 0;
	seqno = seqno + 1;	
}

#if 0
void  InitCheckValue(time_t *stm, time_t *etm, int *sndcnt)
{
	*stm    = time(NULL);
	*etm    = *stm + GIP_SEND_CHKTIME;			/* 10�� */
	*sndcnt = 0;
}
#endif 

int PacketShift(char *dst, char *src, int sz, int *len, int *acc)
{
    int k;
    for(k = 0; k < sz; k++) 
		dst[k] = src[k];
    if(len != NULL) *len = sz;
    if(acc != NULL) *acc = 0;

	return ROK;
}

int CheckCorrect(GipPacket *pack)
{
	int		result;
	
	if(pack==NULL) 
		return GI_RES_Q_INSERT_RAILED;

	/* msgverid check */
    if(pack->head.msgverid != GIP_MSGVERID) {
        logmsg("GIP_MSGVERID[%d]�� �߸��Ǿ����ϴ�. Val[%d]",GIP_MSGVERID,pack->head.msgverid);

    }
    	
    /* msgcode check */
    switch(pack->head.msgcode.msgcode) {
	case MSG_SM_REQ 		:		/* SMS Request			*/
		if(pack->head.msgcode.msgsubcode != MSG_SUB_TRANS_RESULT) {
        	logmsg("Sender���� ����ϴ� MsgCode�Դϴ�. Val[%d]", pack->head.msgcode.msgcode);
        	return GI_RES_FORMAT_MSG_CODE;
        }
	case MSG_SM_RES 		:		/* SMS Response 		*/
		break;
    default:						
        logmsg("MsgCode �߸��Ǿ����ϴ�. Val[%d]", pack->head.msgcode.msgcode);
        return GI_RES_FORMAT_MSG_CODE;
    }  
    
	/* msg subcode check */
    switch(pack->head.msgcode.msgsubcode) {
	case MSG_SUB_LINK 			:		/* link			*/
		if(pack->head.bodylen != 4) {
 	        logmsg("MSG_SUB_LINK�� Body Length�� 0�Դϴ�. Val[%d]", pack->head.bodylen);
	        return GI_RES_FORMAT_INVALID;
		}
		else {
			memcpy(&result, pack->body, (size_t)pack->head.bodylen);
			if(result != GI_RES_NO_ERROR) {
				logmsg("MSG_SUB_LINK�� Result Error[%d]�Դϴ�. Val[%d]", result);
				return result;
			}
		}
		break;
	case MSG_SUB_SIMPLE1 		:		/* MDM 			*/
	case MSG_SUB_SIMPLE2 		:		/* Portedout 	*/
	case MSG_SUB_TRANS_RESULT 	:		/* trans result	*/
		break;
    default:						
        logmsg("MsgSubCode�� �߸��Ǿ����ϴ�. Val[%d]", pack->head.msgcode.msgsubcode);
        return GI_RES_FORMAT_MSG_CODE;
    }
    
	return GI_RES_NO_ERROR;
}

void GipReqResultMsg(int result, char *msg)
{
	if(result == GI_RES_NO_ERROR) 						strcpy(msg, "��û ����");
	else if(result == GI_RES_SUBS_INVALID)				strcpy(msg, "������ ����");
	else if(result == GI_RES_SUBS_SUSPENDED) 			strcpy(msg, "������� ������");
	else if(result == GI_RES_SUBS_INVALID_TERM) 		strcpy(msg, "�ѱ�,���� ���� ������");
	else if(result == GI_RES_SUBS_INVALID_TERM_KOR) 	strcpy(msg, "�ѱ۰������ε�, ���������ڷ�");
	else if(result == GI_RES_SUBS_INVALID_TERM_ENG) 	strcpy(msg, "�����������ε�, �ѱ۰����ڷ�");
	else if(result == GI_RES_SUBS_INVALID_CALLNO) 		strcpy(msg, "���Ź�ȣ�� �����ϰ��(�ڸ�������)");
	else if(result == GI_RES_URL_SUBS_INVALID_CALLNO) 	strcpy(msg, "Url SMS������ ����DB�� �̵���� ����");
	else if(result == GI_RES_FORMAT_INVALID) 			strcpy(msg, "�޽������� ����");
	else if(result == GI_RES_FORMAT_INVALID_CID) 		strcpy(msg, "CID�� ��ϵǾ� ���� ���� ���");
	else if(result == GI_RES_FORMAT_MSG_CODE) 			strcpy(msg, "MsgCode�� ��ϵǾ� ���� ���� ���");
	else if(result == GI_RES_FORMAT_MSG_SUBCODE) 		strcpy(msg, "MsgSubCode�� ��ϵǾ� ���� ���� ���");
	else if(result == GI_RES_FORMAT_MSG_SEQNO) 			strcpy(msg, "Sequence Number ����(�ߺ�,������)");
	else if(result == GI_RES_FORMAT_DATA_TYPE) 			strcpy(msg, "Data Type ����");
	else if(result == GI_RES_FC_NAK) 					strcpy(msg, "flow over =>������ ������");
	else if(result == GI_RES_Q_INSERT_RAILED) 			strcpy(msg, "�ý��� ��� =>������ ������");
	else												strcpy(msg, "������ ����");
}

void GipTransResultMsg(int result, char *msg)
{
	if(result == GI_TRNAS_NO_ERROR)         strcpy(msg, "���� ����");
	else if(result == GI_TRNAS_ERR_TIMEOUT) strcpy(msg, "�ð� �ʰ�");
	else if(result == GI_TRNAS_ERR_SEND)    strcpy(msg, "���� �Ұ�/NPDB������ ����");
	else if(result == GI_TRNAS_ERR_PORTED)  strcpy(msg, "��ȣ�̵� ������");
	else if(result == GI_TRNAS_ERR_KTF)     strcpy(msg, "KTF�� ��ȣ �̵�");
	else if(result == GI_TRNAS_ERR_LGT)     strcpy(msg, "LGT�� ��ȣ �̵�");
	else if(result == GI_TRNAS_ERR_NPDB)    strcpy(msg, "NPDB ����");
	else                                    strcpy(msg, "������ ����");
}

int ParsePacket(GipPacket *pack, int tot, SMGipRstDataRec *org, GipHead phead)
{
	int		ret, hlen, blen, result;
	char	minno[16], msgid[20];
	GipHead	head;
	GipSmResBody smbody;
	GipTrResBody trbody;
	GipWaitRec  wrec;

	if(tot < 1) {
		logmsg("msgverid:%d, total length:%d error", phead.msgverid, tot);	
		return RFAIL;
	}

	hlen = sizeof(GipHead);
	memset(&head,  0x00, (size_t)hlen);
	memset(&smbody, 0x00, sizeof(GipSmResBody));
	memset(&trbody, 0x00, sizeof(GipTrResBody));
	memcpy(&head, &pack->head, (size_t)hlen);
	blen = head.bodylen;
	
	/* msg subcode Parse */
    switch(head.msgcode.msgsubcode) {
	case MSG_SUB_LINK 			:		/* link			*/
		memcpy(&result, pack->body, (size_t)pack->head.bodylen);
		//int �� 4byte ��. CheckCorrect���� üũ��
		logmsg("MSG_SM_RES/SM_MSG_SUB_LINK Result[%d] Received", result);	
		gRetryCnt = 0;
		break;

	case MSG_SUB_SIMPLE1 		:		/* MDN 			*/
		memcpy(&smbody, pack->body, (size_t)blen);
		memset(errmsg, 0x00, sizeof(errmsg));

		GipReqResultMsg(smbody.result, errmsg);
		if(smbody.result != GI_RES_NO_ERROR)
			logmsg("MSG_SM_RES/MSG_SUB_SIMPLE1(MDN) Received, smsseq[%d], msgid[%s], Error Result[%d]", head.msgseqno, smbody.msgid, smbody.result);
		else
			logmsg("MSG_SM_RES/MSG_SUB_SIMPLE1(MDN) Received, smsseq[%d], msgid[%s]", head.msgseqno, smbody.msgid);
		break;
	
	case MSG_SUB_TRANS_RESULT 	:		/* trans result	*/
		memcpy(&trbody, pack->body, (size_t)blen);
		memset(errmsg, 0x00, sizeof(errmsg));

		GipTransResultMsg((int)trbody.msgstatus, errmsg);
		if((int)trbody.msgstatus != GI_TRNAS_NO_ERROR)
        	logmsg("MSG_SM_REQ/MSG_SUB_TRANS_RESULT Received, msgid[%s], Error Result[%d][%s] ", trbody.msgid, (int)trbody.msgstatus, errmsg);			         	
		else 
            logmsg("MSG_SM_REQ/MSG_SUB_TRANS_RESULT Received, msgid[%s]", trbody.msgid); 
		break;

    default:						
        logmsg("MsgSubCode�� �߸��Ǿ����ϴ�. Val[%d]", pack->head.msgcode.msgsubcode);
		return GI_RES_FORMAT_MSG_CODE;
    }
    
    return ROK;
}

int PacketCheck(SMGipRstDataRec *org, GipHead phead)
{
    int 	ret,tot=0, hlen, blen;
	GipPacket	pack;	
	
	hlen = sizeof(GipHead);
    if(_workpos < hlen) {
        _workend = _workpos;
        return GIP_TIMEOUT;
    }
    memset(&pack, 0x00, sizeof(GipPacket));
    memcpy(&pack.head, _worktmp, (size_t)hlen);

	VsmsMakeHost_GipHead(&pack.head);

	blen = pack.head.bodylen;

	tot = hlen + blen;
	if(blen > 0) memcpy(pack.body, _worktmp+hlen, (size_t)blen);

#if 0
	if(pack.head.msgcode.msgsubcode != MSG_SUB_LINK && CfgLogMode == 1)
    	IFLogDump(BL(SLIF|15),_worktmp, tot, 1, NULL);
#endif

	PacketShift(&_worktmp[0], &_worktmp[tot], _workpos-tot, &_workpos, &_workend);
	gLastJobTime = time(NULL) + GIP_LINK_TIME;	

	if((ret=CheckCorrect(&pack))==GI_RES_NO_ERROR) {
        ret = ParsePacket(&pack, tot, org, phead);
        if(ret != ROK) {
			//AddTongA(tiVSMS, APPPRMAP->mc, vsmsRERR, 1);
            //if(CfgLogMode == 0) IFLogDump(BL(SLIF|15),(char *)&pack, tot, 1, NULL); /* receive raw data */
            return GIP_FAIL;
        }
    }
    else {
		//AddTongA(tiVSMS, APPPRMAP->mc, vsmsRERR, 1);
		//if(CfgLogMode == 0) IFLogDump(BL(SLIF|15),(char *)&pack, tot, 1, NULL);	 	/* receive raw data */
		logmsg("PacketCheck> ���������� ��Ŷ�� �޾ҽ��ϴ�.");
		return GIP_FAIL;
    }
    	
    return GIP_OK;
}

int MonPacketData(SMGipRstDataRec *org, GipHead phead)
{
    int 	k, len, blen, ret=0;
    char 	buf[8192];
    struct pollfd pfd;
    int sz, ms = _workon?_workon:100;

    pfd.fd = gFD;
    pfd.events = (short)(POLLIN|POLLERR|POLLHUP);

    for(k = 0; k < 10; k++) {
        if(_workpos > 0 && _workend != _workpos) {
        	ret = PacketCheck(org, phead);
            if(ret == GIP_TIMEOUT)   {	continue;			}
	        else if(ret == GIP_OK) 	 { 	return GIP_OK;	}
	        else if(ret == GIP_FAIL) {	return GIP_FAIL;	}
        }
        else break;
    }
	
	blen = sizeof(buf);

    if((sizeof(_worktmp) - _workpos) < blen) 
		len = (int)sizeof(_worktmp) - _workpos;
    else 	
		len = blen;
    
	if(len <= 0) 
		return GIP_TIMEOUT;

    if(poll(&pfd, 1, ms) > 0) {
        if((pfd.revents&POLLERR)==POLLERR || (pfd.revents&POLLHUP)==POLLHUP) {
            logmsg("MonPacketData, system port monitor error.(poll error)");		/* NETWORK ERROR Check */
			logmsg("���μ����� �����մϴ�\n");
            exit(-1);
        }
        else if((pfd.revents & POLLIN) == POLLIN) {
            memset(buf, 0x00, sizeof(buf));
            if((sz = (int)read(gFD, buf, (size_t)(len-1))) > 0) {
                memcpy(_worktmp+_workpos, buf, (size_t)sz);
                _workpos += sz;
                _workend = 0;
            }
            else if(sz <= 0) {
                if(errno == EINTR) 
					return ROK;
                logmsg("Disconnect,read count[%d].", sz);		/* NETWORK ERROR Check */
				logmsg("���μ����� �����մϴ�\n");
                exit(-1);
            }
        }
    }
    if(_workend != _workpos) _workon = 1;
	
    return GIP_TIMEOUT;
}


int WriteGipMsg(int size, char *wbuffer)
{
    int     ret;
    struct pollfd fd[2];

    fd[0].fd = gFD;
    fd[0].events = POLLIN;
    poll(fd, 1, 10);
    if(fd[0].revents == POLLERR){
        close(gFD);
        logmsg("WriteGipMsg Socket Error [%d].", errno);

		return RFAIL;
    }

	ret = HSwrite(gFD, wbuffer, size);
    if(ret != size) {
        logmsg("WriteGipMsg send length[%d] != write length[%d].", ret, size);
		return RFAIL;
    }
	return ROK;
}

int GipReadData(SMGipRstDataRec *org, GipHead phead, int tmout)
{
	int		ret;
	time_t	twait;
	twait = time(NULL) + tmout;
	
	for(;;) {
		if(time(NULL) > twait) {
	        logmsg("��û�� ���ɿ� ���� ����� ���� ���߽��ϴ�.");
			break;
		}
		ret = MonPacketData(org, phead);
		if(ret == GIP_FAIL) 	
			return GIP_FAIL;
		else if (ret == GIP_OK)
			return GIP_OK;
	}
	return GIP_TIMEOUT;
}

int GipResultRead(void)
{
	int     ret;
	GipHead head;
	SMGipRstDataRec trec;

	memset(&trec, 0x00, sizeof(SMGipRstDataRec));
	memset(&head, 0x00, sizeof(GipHead));
	head.msgcode.msgcode    = MSG_SM_REQ;                   /* Message Code                 */
	head.msgcode.msgsubcode = MSG_SUB_TRANS_RESULT;         /* Message SubCode              */
	ret = MonPacketData(&trec, head);
	return ROK;
}

int SendGipLinkCheck(GipHead *phead)
{
	int		ret=0, hlen, blen, plen;
	GipHead	 	head;
	GipAddr		addr;
	char		curdate[20];
	char		sendbuff[512];
	
	hlen = sizeof(GipHead);
	memset(&head, 0x00, (size_t)hlen);

	head.msgverid = GIP_MSGVERID;              				/* �ش� �޽����� �ĺ���         */
	memset(&addr, 0x00, sizeof(addr));

	memcpy(addr.cid, gSource_cid, 16);

	addr.callno = 0;
	addr.addrrsv = 0;	
	memcpy(&head.srcaddr, &addr, sizeof(GipAddr));        	 /* Source CID                   */

	memset(&addr, 0x00, sizeof(addr));
	memcpy(addr.cid, "011", 3);
	addr.callno  = 0;
	addr.addrrsv = 0;	
	memcpy(&head.dstaddr, &addr, sizeof(GipAddr));         	/* Destination CID 				*/

	head.msgcode.msgcode    = MSG_SM_REQ;               	/* Message Code                 */
	head.msgcode.msgsubcode = MSG_SUB_LINK;               	/* Message SubCode              */
	head.telsvcid           = 0;              				/* Tele Service ID              */
	head.msgcodersv         = 0;              				/* Reserved                     */
	head.bodylen            = 0;              				/* Body Data Length             */
	head.msgseqno           = seqno;      					/* Message Seqence Number       */
	head.termtype           = 0;              				/* �ܸ��� ����                  */
	head.datatype           = 0; 							/* Data(�ѱ�,����) ����         */

	memset(curdate, 0x00, sizeof(curdate));
	GetCurDateA(curdate);
	strncpy(head.curtime, curdate+2, 10);					/* YYMMDDHHMM                   */
	memcpy(phead, &head, sizeof(GipHead));

	blen = 0;
	plen = hlen + blen;

#if 0
	logmsg("msgverid[%d]", head.msgverid);
	logmsg("msgcode[%d]", head.msgcode.msgcode);
	logmsg("msgsubcode[%d]", head.msgcode.msgsubcode);
	logmsg("msgseqno[%d]", head.msgseqno);
	logmsg("curtime[%s]", head.curtime);
#endif

	VsmsMakeNetwork_GipHead(&head);
	memset(sendbuff, 0x00, sizeof(sendbuff));
	memcpy(sendbuff, &head, (size_t)hlen);		/* length => 120 */

	if(WriteGipMsg(plen, sendbuff) != ROK) {
		logmsg("SendGipLinkCheck wirte plen[%d] sndlen[%d]", plen, ret);
        return RFAIL;
    }

	return ROK;
}

int GipLinkCheckMsg()
{
    int     ret;
    GipHead head;
    SMGIPRSTDATAREC trec=NULL;

    if(gRetryCnt >= GIP_LINK_RETRY)  {
        logmsg("������� ����(MSG_SUB_LINK) ACK Not Received %d Retry!!", GIP_LINK_RETRY);
		logmsg("���μ����� �����մϴ�\n");
        exit(-1);
    }

    /* LinkCheck Message ������ */
    if(seqno == 0) MsgSeqNoIncrement();

    memset(&head, 0x00, sizeof(GipHead));
    if((ret = SendGipLinkCheck(&head))!= ROK) {
        logmsg("������� ����(MSG_SUB_LINK) Send ����!!");
		logmsg("���μ����� �����մϴ�\n");
		exit(-1);
    }

    gRetryCnt ++;
    logmsg("������� ����(MSG_SUB_LINK) Send �õ�[%d]!!", gRetryCnt);

    ret=GipReadData(trec, head, GIP_RES_TIME);
    if(ret != GIP_OK) {
        logmsg("������� ����(MSG_SUB_LINK) ������ð� �ʰ�[%d]!!", gRetryCnt);
		return RFAIL;
    }
	return ROK;
}
int sendSms(char *msg, int telecom, GipHead *phead)
{
	int			ret=0, hlen, blen, plen, slen;
	GipHead	 	head;
	GipReqBody	body;
	GipAddr		addr;
	GipSndRec	smsdata;
	char		curdate[20], tmp[20];
	char		smsmsg[256];
	char		sendbuff[1024];
	
	memset(&smsdata, 0x00, sizeof(GipSndRec));
//	memcpy(&smsdata, &mrec.data, sizeof(GipSndRec));
	hlen = sizeof(GipHead);
	memset(&head, 0x00, (size_t)hlen);
	head.msgverid = GIP_MSGVERID;              				/* �ش� �޽����� �ĺ���         */
	
	memset(&addr, 0x00, sizeof(addr));
	memcpy(addr.cid, gSource_cid, 16);
	addr.callno = 0;
	addr.addrrsv = 0;
	memcpy(&head.srcaddr, &addr, sizeof(GipAddr));        	/* Source CID                   */

	memset(&addr, 0x00, sizeof(addr));
	if(telecom==SKT)
	{
		memcpy(addr.cid, gDest_num_skt, 3);
		memset(tmp, 0x00, sizeof(tmp));
		strcpy(tmp, gDest_num_skt+3);
		addr.callno  = atoi(tmp);
		addr.addrrsv = 0;	
	}
	else if (telecom == KT)
	{
		memcpy(addr.cid, gDest_num_kt, 3);
		memset(tmp, 0x00, sizeof(tmp));
		strcpy(tmp, gDest_num_kt+3);
		addr.callno  = atoi(tmp);
		addr.addrrsv = 0;	

	}
	else if (telecom == LGT)
	{
		memcpy(addr.cid, gDest_num_lgt, 3);
		memset(tmp, 0x00, sizeof(tmp));
		strcpy(tmp, gDest_num_lgt+3);
		addr.callno  = atoi(tmp);
		addr.addrrsv = 0;	
	}
	else
	{
		logmsg("TELECOM ������ �����ϴ�..?");
		return RFAIL;
	}

	memcpy(&head.dstaddr, &addr, sizeof(GipAddr));         	/* Destination CID 				*/
	head.msgcode.msgcode    = MSG_SM_REQ;               	/* Message Code                 */
	head.msgcode.msgsubcode = MSG_SUB_SIMPLE1;             	/* Message SubCode              */
	head.telsvcid  = (short)(atoi(gTelesvcid)); 				/* Tele Service ID              */
	head.msgcodersv         = 0;              				/* Reserved                     */
	head.bodylen            = 209;		        			/* body data length, 209		*/
	head.msgseqno           = seqno;      					/* Message Seqence Number       */
	head.termtype           = TERM_TYPE_KOR;              	/* �ܸ��� ����                  */
	head.datatype           = DATA_ENCODING_KSC5601; 			/* Data(�ѱ�,����) ����         */

	memset(curdate, 0x00, sizeof(curdate));
	//LToDateA(time(NULL), curdate);
	GetCurDateA(curdate);
	strncpy(head.curtime, curdate+2, 10);					/* YYMMDDHHMM                   */
	memcpy(phead, &head, (size_t)hlen);

	blen = 209;												/* blen = 209; */
	
	memset(&body, 0x00, sizeof(GipReqBody));
	body.vldprd    = MAXGIPEXPIED;							/* Valid Period(�ʴ���)-SKTȮ�� 		*/
	body.rgtdlvflg = 2;										/* ���ް���� ���� ������? 2:MT, MO:0 	*/
	strncpy(body.callback, gCallback_num, 21);		/* Callback Number              		*/

	memset(smsmsg, 0x00, sizeof(smsmsg));
	strcpy(smsmsg, msg);
	body.smslen    = strlen(smsmsg); 					//(char)(smsdata.smslen + slen);
	if(body.smslen > sizeof(body.smsmsg)) body.smslen = sizeof(body.smsmsg);
	memcpy(body.smsmsg, smsmsg, (size_t)body.smslen);

	body.reserved[0] = 0; 

	memset(sendbuff, 0x00, sizeof(sendbuff));
	VsmsMakeNetwork_GipHead(&head);
	memcpy(sendbuff,      &head, (size_t)hlen);				/* length => 120					*/
	body.vldprd = htonl(body.vldprd);

	memcpy(sendbuff+hlen, &body, (size_t)blen);             /* length => 156, GIP 5.0.0���� 212 */
	plen = hlen + blen;                                     /* length => 276, GIP 5.0.0���� 332 */

#if 0
	logmsg("GipSend Message Total Length[%d]", plen);	
	logmsg("GipSend Message:DcsType=[%d]", head.datatype);		
	logmsg("GipSend Message:Original Msg Total Length=[%d]",body.reserved[0]);
	logmsg("GipSend Message:vldprd=[%d]", body.vldprd);
	logmsg("GipSend Message:rgtdlvflg=[%d]", body.rgtdlvflg);		
	logmsg("GipSend Message:callback=[%s]", body.callback);		
	logmsg("GipSend Message:smsmsg=[%s]", body.smsmsg);		
	logmsg("GipSend Message:smslen=[%d]", body.smslen);		
	logmsg("GipSend Message:seqno=[%d]", head.msgseqno);		
#endif

	if(gCfgLogMode == 1) IFLogDumpK(sendbuff, plen);

 	if(WriteGipMsg(plen, sendbuff) != ROK) {
		logmsg("SendGipSmsReq Minno[%s], write plen[%d] sndlen[%d]", smsdata.minno, plen, ret);
        return RFAIL;
    } 	

/* send log */
	logmsg("SendGipSmsReq ��û ����! seq[%d]", seqno);
	gSendCount++;

	return ROK;		
}

int sendAlarm(char *srcnum, char *msg, GipHead *phead)
{
	int			ret=0, hlen, blen, plen, slen;
	GipHead	 	head;
	GipReqBody	body;
	GipAddr		addr;
	GipSndRec	smsdata;
	char		curdate[20], tmp[20];
	char		smsmsg[256];
	char		sendbuff[1024];
	
	memset(&smsdata, 0x00, sizeof(GipSndRec));
	hlen = sizeof(GipHead);
	memset(&head, 0x00, (size_t)hlen);
	head.msgverid = GIP_MSGVERID;              				/* �ش� �޽����� �ĺ���         */
	
	memset(&addr, 0x00, sizeof(addr));
	memcpy(addr.cid, gSource_cid, 16);
	addr.callno = 0;
	addr.addrrsv = 0;
	memcpy(&head.srcaddr, &addr, sizeof(GipAddr));        	/* Source CID                   */

	memset(&addr, 0x00, sizeof(addr));
	memcpy(addr.cid, srcnum, 3);
	memset(tmp, 0x00, sizeof(tmp));
	strcpy(tmp, srcnum+3);
	addr.callno  = atoi(tmp);
	addr.addrrsv = 0;	

	memcpy(&head.dstaddr, &addr, sizeof(GipAddr));         	/* Destination CID 				*/
	head.msgcode.msgcode    = MSG_SM_REQ;               	/* Message Code                 */
	head.msgcode.msgsubcode = MSG_SUB_SIMPLE1;             	/* Message SubCode              */
	head.telsvcid  = (short)(atoi(gTelesvcid)); 				/* Tele Service ID              */
	head.msgcodersv         = 0;              				/* Reserved                     */
	head.bodylen            = 209;		        			/* body data length, 209		*/
	head.msgseqno           = seqno;      					/* Message Seqence Number       */
	head.termtype           = TERM_TYPE_KOR;              	/* �ܸ��� ����                  */
	head.datatype           = DATA_ENCODING_KSC5601; 			/* Data(�ѱ�,����) ����         */

	memset(curdate, 0x00, sizeof(curdate));
	//LToDateA(time(NULL), curdate);
	GetCurDateA(curdate);
	strncpy(head.curtime, curdate+2, 10);					/* YYMMDDHHMM                   */
	memcpy(phead, &head, (size_t)hlen);

	blen = 209;												/* blen = 209; */
	
	memset(&body, 0x00, sizeof(GipReqBody));
	body.vldprd    = MAXGIPEXPIED;							/* Valid Period(�ʴ���)-SKTȮ�� 		*/
	body.rgtdlvflg = 2;										/* ���ް���� ���� ������? 2:MT, MO:0 	*/
	strncpy(body.callback, "01089655467", 21);		/* Callback Number              		*/

	memset(smsmsg, 0x00, sizeof(smsmsg));
	strcpy(smsmsg, msg);
//	sprintf(smsmsg, "�������͸� ���� ���Թ�ȣ �˶� : %s", msg);
	snprintf(smsmsg, 139, "%s", msg);
	body.smslen    = strlen(smsmsg); 					//(char)(smsdata.smslen + slen);
	if(body.smslen > sizeof(body.smsmsg)) body.smslen = sizeof(body.smsmsg);
	memcpy(body.smsmsg, smsmsg, (size_t)body.smslen);

	body.reserved[0] = 0; 

	memset(sendbuff, 0x00, sizeof(sendbuff));
	VsmsMakeNetwork_GipHead(&head);
	memcpy(sendbuff,      &head, (size_t)hlen);				/* length => 120					*/
	body.vldprd = htonl(body.vldprd);

	memcpy(sendbuff+hlen, &body, (size_t)blen);             /* length => 156, GIP 5.0.0���� 212 */
	plen = hlen + blen;                                     /* length => 276, GIP 5.0.0���� 332 */

#if 0
	logmsg("GipSend Message Total Length[%d]", plen);	
	logmsg("GipSend Message:DcsType=[%d]", head.datatype);		
	logmsg("GipSend Message:Original Msg Total Length=[%d]",body.reserved[0]);
	logmsg("GipSend Message:vldprd=[%d]", body.vldprd);
	logmsg("GipSend Message:rgtdlvflg=[%d]", body.rgtdlvflg);		
	logmsg("GipSend Message:callback=[%s]", body.callback);		
	logmsg("GipSend Message:smsmsg=[%s]", body.smsmsg);		
	logmsg("GipSend Message:smslen=[%d]", body.smslen);		
	logmsg("GipSend Message:seqno=[%d]", head.msgseqno);		
#endif

	if(gCfgLogMode == 1) IFLogDumpK(sendbuff, plen);

 	if(WriteGipMsg(plen, sendbuff) != ROK) {
		logmsg("SendGipSmsReq Minno[%s], write plen[%d] sndlen[%d]", smsdata.minno, plen, ret);
        return RFAIL;
    } 	

/* send log */
	logmsg("SendGipSmsReq ��û ����! seq[%d]", seqno);
	gSendCount++;

	return ROK;		
}


int sendSmsList()
{
	int ret = 0;
	FILE *pfd;
	char line[4001];
	char *line_p;
	char msg[141];
    SMGIPRSTDATAREC trec=NULL;
	GipHead head;
	time_t waitingTime;

	if((pfd=fopen("list.txt", "r")) == NULL)
	{
		logmsg("list.txt ������ �������� �ʽ��ϴ�.");
		return RFAIL;
	}

	memset(line, 0x00, sizeof(line));
	while(fgets(line, sizeof(line), pfd) != NULL)
	{	
		checkNotice();	
		load_config();
		if(gStatus==2)
		{
			logmsg("�߼��� �Ͻ� �����Ǿ����ϴ�. conf ���� Ȯ��");
			while(1)
			{
				load_config();
				if(gStatus != 2)
					break;
				// link check
				if(time(NULL) > gLastJobTime)
					GipLinkCheckMsg();
				GipResultRead();
				poll(0,0,20);
			}
		}
		if(gStatus==1)
		{
			if((line_p = strchr(line, '\n')) != NULL)*line_p ='\0';
			if((line_p = strchr(line, '\r')) != NULL)*line_p ='\0';
			if(strlen(line) > 0)
			{
				memset(msg, 0x00, sizeof(msg));
				strncpy(msg, line, 140);
				logmsg("%s[%dbyte]", msg, strlen(msg)); 

#ifdef _AUTOINCREMENT
				if(gCbnum_autoupflag)
				{
					sprintf(gCallback_num, "0109999%04d", gCbnum_inc);
					gCbnum_inc++;
				}
#endif

				if(gSend_skt==1)
				{
					MsgSeqNoIncrement();
					memset(&head, 0x00, sizeof(GipHead));
					sendSms(msg, SKT, &head);
					ret=GipReadData(trec, head, GIP_RES_TIME);
					if(ret != GIP_OK) {
						logmsg("GipReadData Error");
					}
					GipResultRead();
					//usleep(gTps);
					poll(0,0, gTps);
				}

				if(gSend_kt==1)
				{	
					MsgSeqNoIncrement();
					memset(&head, 0x00, sizeof(GipHead));
					sendSms(msg, KT, &head);
					ret=GipReadData(trec, head, GIP_RES_TIME);
					if(ret != GIP_OK) {
						logmsg("GipReadData Error");
					}
					GipResultRead();
					//usleep(gTps);
					poll(0,0, gTps);
				}

				if(gSend_lgt==1)
				{	
					MsgSeqNoIncrement();
					memset(&head, 0x00, sizeof(GipHead));
					sendSms(msg, LGT, &head);
					ret=GipReadData(trec, head, GIP_RES_TIME);
					if(ret != GIP_OK) {
						logmsg("GipReadData Error");
					}
					GipResultRead();
					//usleep(gTps);
					poll(0,0, gTps);
				}

			}
			if(gIntervalCount >= gCall_interval && gCall_interval != 0)
			{
				logmsg("Interval Waiting....[%dCall/%dSec]", gCall_interval, gTime_interval);
				gIntervalCount = 1;	   
				waitingTime=time(NULL) + gTime_interval;
				while(1)
				{
					if(time(NULL) > waitingTime)
						break;
					else
					{
						// link check
						if(time(NULL) > gLastJobTime)
							GipLinkCheckMsg();
					}
					GipResultRead();
					poll(0,0,20);
				}
			}
			else
				gIntervalCount++;
		}
		else
		{
			logmsg("�޽��� �߼��� �ߴܵǾ����ϴ�");
			break;
		}
	}

	fclose(pfd);
	
	return ROK;
}

int sendNoticeMsg(char *smsfile, char *numlist)
{
	int ret = 0;
	FILE *fp_smsfile, *fp_numlist;

	char msg[141];
	char line[1000];
	char *line_p;
	char srcnum[12];

	SMGIPRSTDATAREC trec = NULL;
	GipHead head;

	if(access(smsfile, 0) != 0)
		return ROK;

	logmsg("notice ���� ���� - ���� �߼�");

	fp_smsfile=fopen(smsfile, "r");

	memset(msg, 0x00, sizeof(msg));
	fgets(msg, sizeof(msg), fp_smsfile);
	fclose(fp_smsfile);

	if((fp_numlist=fopen(numlist, "r")) == NULL)
	{
		logmsg("[%s] ������ �������� �ʽ��ϴ�", numlist);
		return RFAIL;
	}

	memset(line, 0x00, sizeof(line));
	while(fgets(line, sizeof(line), fp_numlist) != NULL)
	{
		if((line_p = strchr(line, '\n')) != NULL)*line_p ='\0';
		if((line_p = strchr(line, '\r')) != NULL)*line_p ='\0';
		if(strlen(line) > 0)  
		{
			memset(srcnum, 0x00, sizeof(srcnum));
			strncpy(srcnum, line, sizeof(srcnum));

			MsgSeqNoIncrement();
			memset(&head, 0x00, sizeof(GipHead));

			sendAlarm(srcnum, msg, &head);
			ret=GipReadData(trec, head, GIP_RES_TIME);
			if(ret != GIP_OK) {
				logmsg("GipReadData Error");
			}
			GipResultRead();
			poll(0,0, gTps);
		}
	}
	fclose(fp_numlist);

	remove(smsfile);
	return ROK;
}

#if 0
int check_alarm()
{
	int ret = 0;
	FILE *pfd, *fp;
	char msg[141];
	char line[1000];
	char *line_p;
	char srcnum[12];
	SMGIPRSTDATAREC trec = NULL;
	GipHead head;

	if(access("./alarm.txt", 0) != 0)
		return ROK;

	logmsg("�˶� ���� ���� - ���� �߼�");

	fp=fopen("alarm.txt", "r");
	memset(msg, 0x00, sizeof(msg));
	fgets(msg, sizeof(msg), fp);
	fclose(fp);

	if((pfd=fopen("admin.txt", "r")) == NULL)
	{
		logmsg("admin.txt ������ �������� �ʽ��ϴ�");
		return RFAIL;
	}

	memset(line, 0x00, sizeof(line));
	while(fgets(line, sizeof(line), pfd) != NULL)
	{
		if((line_p = strchr(line, '\n')) != NULL)*line_p ='\0';
		if((line_p = strchr(line, '\r')) != NULL)*line_p ='\0';
		if(strlen(line) > 0)  
		{
			memset(srcnum, 0x00, sizeof(srcnum));
			strncpy(srcnum, line, sizeof(srcnum));

			MsgSeqNoIncrement();
			memset(&head, 0x00, sizeof(GipHead));

			sendAlarm(srcnum, msg, &head);
			ret=GipReadData(trec, head, GIP_RES_TIME);
			if(ret != GIP_OK) {
				logmsg("GipReadData Error");
			}
			GipResultRead();
			poll(0,0, gTps);
		}
	}
	fclose(pfd);

	remove("./alarm.txt");
	return ROK;

}
#endif

int epoll_connect_block_mode()
{

    int connect_fd = 0;
    int result = 0;

    struct sockaddr_in connect_addr;

    int val=0;
    socklen_t val_len = sizeof(val);

    if((connect_fd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {
        return -1;
    }

    memset(&connect_addr, 0x00, sizeof(connect_addr));

    connect_addr.sin_family = AF_INET;
    connect_addr.sin_addr.s_addr = inet_addr(gIp);
    connect_addr.sin_port = htons(gPort);

    setsockopt(connect_fd, SOL_SOCKET, SO_LINGER, &s_linger_option, sizeof(s_linger_option));
    setsockopt(connect_fd, SOL_SOCKET, SO_KEEPALIVE,&s_val, sizeof(int));

    result = connect(connect_fd, (struct sockaddr *)&connect_addr, sizeof(struct sockaddr));

    if(result == 0)
    {
        return connect_fd;
    } else
    {
        return 0;
    }

    return connect_fd;
}

int checkNotice()
{
	FILE *fp = fopen("notice.cfg", "r");
	char buff[256];
	char msgpath[256];
	char numberpath[256];

	while(readline(fp, buff, 128) != -1)
	{
		if(buff[0]=='#')
			continue;
		token(buff, buff, "|");

		memset(msgpath,0x00, sizeof(msgpath));
		memset(numberpath,0x00, sizeof(numberpath));

		sprintf(msgpath, "./notice/%s.txt", buff);
		sprintf(numberpath, "./notice/%s.num", buff);

		sendNoticeMsg(msgpath, numberpath);      
	}

	fclose(fp);
}

int main(int argc, char *argv[])
{
    int     i, sndcnt=0, init=0;
	int		max, ret, cnt;
	int		waittime;
    char    tmp[100];
    time_t	stm, etm;
	GipHead head;
    //SMGipRstDataRec mrec[GIP_SEND_SMSCNT];

	logmsg("sendsms ���μ����� �����մϴ�.");
	ret = load_config();
	gStatus=0; // ���� �⵿�ÿ��� ������ ��������
	seqno=0;
	
    if(ret == RFAIL) {
        logmsg("vsms.conf file error");
		logmsg("���μ����� �����մϴ�\n");
		exit(-1);
    }

	print_config();


#if 1
	while(1)
	{
		gConnect=0;
		gFD = epoll_connect_block_mode();
		if (gFD <= 0) {
			logmsg("���ӿ��� ����, IP[%S]/PORT[%d]", gIp, gPort);
			poll(0,0, 7000);	/* �����ӽ� 7�� ��� */
		}
		else
			break;
	}
    
	gConnect=1;
    gRetryCnt = 0;
	gLastJobTime = time(NULL) + GIP_LINK_TIME;
	
	logmsg("IP[%s] PORT[%d] ���������� �����Ǿ����ϴ�.", gIp, gPort);

    for (;;) {

		load_config();

    	/* 1. link check => ����Data�� 1�е��� ���� ��� */
    	if(time(NULL) > gLastJobTime) {
 			GipLinkCheckMsg();			
    	}

		checkNotice();

		if(gStatus==1)
		{
			logmsg("�޽��� �߼� ����");
			gSendCount=0;
			gIntervalCount=1;

#ifdef _AUTOINCREMENT
			gCbnum_inc=1;
#endif

			if((ret = sendSmsList()) != ROK) 
				logmsg("�޽��� �߼��� �����Ͽ����ϴ�");
			else
				logmsg("�޽��� �߼��� �Ϸ�Ǿ����ϴ�. ��[%d]��", gSendCount);
			set_config();
		}

		GipResultRead();

		poll(0,0,20);
#if 0
        /* 3. sending SMS read */
        max = GIP_SEND_SMSCNT - sndcnt;
        if(max == 0) {
     		InitCheckValue(&stm, &etm, &sndcnt);
     		poll(0,0,10);
    		continue;   	
        }
        waittime = 100;
        memset(mrec, 0x00, sizeof(mrec));
   
 		//cnt = SMGIPRSTFetch(mrec, 1, waittime);
        if(cnt > 0) {
			for(i=0; i < cnt; i++) { \
				memset(&head, 0x00, sizeof(GipHead));
				MsgSeqNoIncrement();
				if((ret=SendGipSmsReq(mrec[i],&head))== RFAIL) {
					end_proc_job(-2);
				}	
				sndcnt ++;
				
				ret=GipReadData(&mrec[i], head, GIP_RES_TIME);
				if(ret != GIP_OK) {
					if(ret == GIP_TIMEOUT) AddTongA(tiVSMS, APPPRMAP->mc, vsmsSERR, 1);
					end_proc_job(-3);
				}
				poll(0,0,20);
	       	}
	    }
	    else {
	    	GipResultRead();
		}
#endif
    }
#endif
	return ROK;
}	
